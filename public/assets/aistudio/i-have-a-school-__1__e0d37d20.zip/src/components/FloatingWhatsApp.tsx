import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { MessageCircle, X, Send, PhoneCall, Home, Lock, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FloatingWhatsApp: React.FC = () => {
  const { lang, schoolSettings, isAdminLoggedIn } = useApp();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  // Clean phone number for WhatsApp link
  const rawNumber = schoolSettings.whatsapp || schoolSettings.phone || '8801700000000';
  const cleanNumber = rawNumber.replace(/[^0-9]/g, '');

  const defaultMessage = lang === 'bn'
    ? 'আসসালামু আলাইকুম স্যার, আমি "আই হ্যাভ এ স্কুল" একাডেমি ও কোর্স সম্পর্কিত তথ্য জানতে চাই।'
    : 'Hello Sir, I would like to get information regarding "I Have A School" courses.';

  const handleOpenWhatsApp = () => {
    const url = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(defaultMessage)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <>
      {/* Floating Action Stack (Home, Admin Panel & WhatsApp) - Vertically Stacked on the Left */}
      <aside
        aria-label={lang === 'bn' ? 'ভাসমান নেভিগেশন ও হেল্পডেস্ক' : 'Floating Navigation and Helpdesk'}
        className="!fixed bottom-4 sm:bottom-6 left-3 sm:left-6 z-[9990] flex flex-col items-start gap-2.5 sm:gap-3 pointer-events-auto select-none"
      >
        {/* 1. ভাসমান মূল পাতা (Home) */}
        <div className="relative group flex items-center">
          <Link
            to="/"
            className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-slate-900 via-slate-800 to-emerald-950 hover:from-slate-800 hover:to-emerald-900 text-white shadow-xl flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 border border-slate-700/80 focus:outline-none focus:ring-2 focus:ring-emerald-400 ${
              location.pathname === '/' ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-900' : ''
            }`}
            title={lang === 'bn' ? 'মূল পাতা (হোম)' : 'Main Page (Home)'}
            aria-label={lang === 'bn' ? 'মূল পাতায় ফিরে যান' : 'Go to Home Page'}
          >
            <Home className="w-5 h-5 text-emerald-400" />
          </Link>

          {/* Tooltip on hover */}
          <span className="hidden sm:inline-flex items-center gap-1.5 absolute left-14 sm:left-16 bg-slate-900/95 backdrop-blur-md text-white text-[11px] font-semibold px-3 py-1.5 rounded-xl shadow-2xl border border-slate-700/80 whitespace-nowrap opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity pointer-events-none z-10">
            <Home className="w-3.5 h-3.5 text-emerald-400" />
            <span>{lang === 'bn' ? 'মূল পাতা' : 'Main Page'}</span>
          </span>
        </div>

        {/* 2. ভাসমান অ্যাডমিন প্যানেল (Admin Panel Dashboard) */}
        <div className="relative group flex items-center">
          <Link
            to="/admin"
            className={`relative w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-tr from-slate-950 via-slate-900 to-indigo-950 hover:from-slate-900 hover:to-indigo-900 text-white shadow-xl flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 border border-indigo-500/40 focus:outline-none focus:ring-2 focus:ring-indigo-400 ${
              location.pathname === '/admin' ? 'ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-900' : ''
            }`}
            title={lang === 'bn' ? 'অ্যাডমিন প্যানেল (লগইন ড্যাশবোর্ড)' : 'Admin Panel & Login'}
            aria-label={lang === 'bn' ? 'অ্যাডমিন প্যানেলে যান' : 'Go to Admin Panel'}
          >
            {isAdminLoggedIn ? (
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            ) : (
              <Lock className="w-5 h-5 text-indigo-300" />
            )}

            {/* Active Indicator if logged in */}
            {isAdminLoggedIn && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 border-2 border-slate-900 rounded-full" />
            )}
          </Link>

          {/* Tooltip on hover */}
          <span className="hidden sm:inline-flex items-center gap-1.5 absolute left-14 sm:left-16 bg-slate-900/95 backdrop-blur-md text-white text-[11px] font-semibold px-3 py-1.5 rounded-xl shadow-2xl border border-slate-700/80 whitespace-nowrap opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity pointer-events-none z-10">
            {isAdminLoggedIn ? <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> : <Lock className="w-3.5 h-3.5 text-indigo-300" />}
            <span>
              {isAdminLoggedIn 
                ? (lang === 'bn' ? 'অ্যাডমিন ড্যাশবোর্ড (সক্রিয়)' : 'Admin Dashboard (Active)')
                : (lang === 'bn' ? 'অ্যাডমিন প্যানেল' : 'Admin Panel')}
            </span>
          </span>
        </div>

        {/* 3. ভাসমান হোয়াটসঅ্যাপ (WhatsApp Action Button) */}
        <div className="relative group flex items-center">
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-[#128C7E] via-[#25D366] to-[#20bd5a] hover:from-[#075E54] hover:to-[#1ebd56] text-white shadow-2xl flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 group focus:outline-none focus:ring-2 focus:ring-emerald-400 border border-emerald-200/40 ${
              isOpen ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-900' : ''
            }`}
            style={{ boxShadow: '0 8px 28px -4px rgba(37, 211, 102, 0.55)' }}
            title={lang === 'bn' ? 'হোয়াটসঅ্যাপে সরাসরি চ্যাট করুন' : 'Chat on WhatsApp'}
            aria-label={lang === 'bn' ? 'হোয়াটসঅ্যাপ হেল্পডেস্ক খুলুন' : 'Open WhatsApp Helpdesk'}
          >
            {/* WhatsApp Official SVG Icon */}
            <svg
              className="w-6 h-6 sm:w-7 sm:h-7 fill-current relative z-10"
              viewBox="0 0 24 24"
            >
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>

            {/* Active online dot */}
            <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-300 border-2 border-white rounded-full pointer-events-none" />
          </button>

          {/* Tooltip on hover */}
          <span className="hidden sm:inline-flex items-center gap-1.5 absolute left-16 sm:left-18 bg-slate-900/95 backdrop-blur-md text-white text-[11px] font-semibold px-3 py-1.5 rounded-xl shadow-2xl border border-slate-700/80 whitespace-nowrap opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity pointer-events-none z-10">
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>{lang === 'bn' ? 'হোয়াটসঅ্যাপ হেল্পডেস্ক' : 'WhatsApp Helpdesk'}</span>
          </span>
        </div>
      </aside>

      {/* Mini WhatsApp Chat Card / Modal */}
      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={lang === 'bn' ? 'তুহিন স্যার হেল্পডেস্ক' : 'Tuhin Sir Helpdesk'}
          className="!fixed bottom-4 sm:bottom-6 left-16 sm:left-22 z-[9999] w-[calc(100vw-80px)] sm:w-80 max-w-xs bg-white rounded-3xl shadow-2xl shadow-emerald-950/40 border border-slate-200 overflow-hidden text-slate-800 animate-scale-in"
        >
          {/* Card Header */}
          <div className="bg-[#075E54] text-white p-3.5 sm:p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white">
                <MessageCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-white">
                  {lang === 'bn' ? 'তুহিন স্যার হেল্পডেস্ক' : 'Tuhin Sir Helpdesk'}
                </h4>
                <p className="text-[10px] text-emerald-200 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#25D366]" />
                  {lang === 'bn' ? 'অনলাইন ও সক্রিয়' : 'Online & Active'}
                </p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-white/10 text-white/80 hover:text-white"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Card Body */}
          <div className="p-3.5 sm:p-4 bg-[#E5DDD5]/40 space-y-2.5 text-xs">
            {/* Simulated WhatsApp incoming message bubble */}
            <div className="bg-white rounded-2xl p-3 shadow-xs border border-slate-200/60 max-w-[95%] space-y-1">
              <p className="font-bold text-[11px] text-emerald-800">
                {lang === 'bn' ? 'মো. তৌহিদুল হক তুহিন' : 'MD Touhidul Hoque Tuhin'}
              </p>
              <p className="text-slate-700 text-[11px] leading-relaxed">
                {lang === 'bn' 
                  ? 'আসসালামু আলাইকুম! যেকোনো কোর্স, ফ্রি ভিডিও ক্লাস বা ভর্তি সংক্রান্ত তথ্যের জন্য সরাসরি হোয়াটসঅ্যাপে মেসেজ দিন।' 
                  : 'Hello! Feel free to message on WhatsApp for any course details, admission rules, or questions.'}
              </p>
              <span className="text-[9px] text-slate-400 block text-right">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-2.5 flex items-center gap-2 text-[11px] text-emerald-900">
              <PhoneCall className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span className="font-mono font-bold">+{schoolSettings.whatsapp || schoolSettings.phone}</span>
            </div>
          </div>

          {/* Card Action */}
          <div className="p-3 bg-white border-t border-slate-100 flex items-center gap-2">
            <button
              onClick={() => {
                handleOpenWhatsApp();
                setIsOpen(false);
              }}
              className="w-full py-2.5 px-4 bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'হোয়াটসঅ্যাপে মেসেজ পাঠান' : 'Start WhatsApp Chat'}</span>
            </button>
          </div>
        </div>
      )}
    </>
  );
};
